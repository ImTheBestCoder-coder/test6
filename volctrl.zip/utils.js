var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// server/utils.ts
var utils_exports = {};
__export(utils_exports, {
  findExecutables: () => findExecutables
});
module.exports = __toCommonJS(utils_exports);
var import_child_process = require("child_process");
function parseTable(data) {
  data = data.replace(/\r/g, "");
  const lines = data.split("\n").slice(5).map((line) => line.trim()).filter((line) => line.trim() !== "").filter((line) => line.includes(" "));
  return lines.map((line) => {
    const [ProcessId, ...ExecutablePathParts] = line.split(" ");
    const ExecutablePath = ExecutablePathParts.join(" ");
    return { ProcessId: parseInt(ProcessId, 10), ExecutablePath };
  });
}
var findExecutables = async (pids) => {
  return new Promise((resolve, reject) => {
    const cmd = "Get-CimInstance -className win32_process | select ProcessId,ExecutablePath";
    const lines = [];
    const proc = (0, import_child_process.spawn)("powershell.exe", ["/c", cmd], {
      detached: false,
      windowsHide: true
    });
    proc.stdout.on("data", (data) => {
      lines.push(data.toString());
    });
    proc.on("error", (err) => {
      reject(
        new Error("Command '" + cmd + "' failed with reason: " + err.toString())
      );
    });
    proc.on("close", (code) => {
      if (code !== 0) {
        return reject(
          new Error("Command '" + cmd + "' terminated with code: " + code)
        );
      }
      const list = parseTable(lines.join("")).filter((row) => {
        return pids.includes(row.ProcessId);
      }).map((row) => ({
        pid: row.ProcessId,
        bin: row.ExecutablePath
      }));
      resolve(list);
    });
  });
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  findExecutables
});
