var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server/audioProcessor.ts
var import_node_audio_volume_mixer = require("node-audio-volume-mixer");
var import_extract_file_icon = __toESM(require("extract-file-icon"), 1);

// server/utils.ts
var import_child_process = require("child_process");
function parseTable(data) {
  data = data.replace(/\r/g, "");
  const lines = data.split("\n").slice(5).map((line) => line.trim()).filter((line) => line.trim() !== "").filter((line) => line.includes(" "));
  return lines.map((line) => {
    const [ProcessId, ...ExecutablePathParts] = line.split(" ");
    const ExecutablePath = ExecutablePathParts.join(" ");
    return { ProcessId: parseInt(ProcessId, 10), ExecutablePath };
  });
}
var findExecutables = async (pids) => {
  return new Promise((resolve, reject) => {
    const cmd = "Get-CimInstance -className win32_process | select ProcessId,ExecutablePath";
    const lines = [];
    const proc = (0, import_child_process.spawn)("powershell.exe", ["/c", cmd], {
      detached: false,
      windowsHide: true
    });
    proc.stdout.on("data", (data) => {
      lines.push(data.toString());
    });
    proc.on("error", (err) => {
      reject(
        new Error("Command '" + cmd + "' failed with reason: " + err.toString())
      );
    });
    proc.on("close", (code) => {
      if (code !== 0) {
        return reject(
          new Error("Command '" + cmd + "' terminated with code: " + code)
        );
      }
      const list = parseTable(lines.join("")).filter((row) => {
        return pids.includes(row.ProcessId);
      }).map((row) => ({
        pid: row.ProcessId,
        bin: row.ExecutablePath
      }));
      resolve(list);
    });
  });
};

// server/audioProcessor.ts
var getAudioData = async () => {
  const sessions = import_node_audio_volume_mixer.NodeAudioVolumeMixer.getAudioSessionProcesses();
  const promises = sessions.map(async (session) => {
    if (session.pid <= 0) return null;
    return {
      name: session.name.replace(".exe", ""),
      pid: session.pid,
      volume: import_node_audio_volume_mixer.NodeAudioVolumeMixer.getAudioSessionVolumeLevelScalar(session.pid)
    };
  });
  return (await Promise.all(promises)).filter((sessionData) => sessionData !== null);
};
var getIcon = async (bin) => {
  const icon = (0, import_extract_file_icon.default)(bin, 32);
  if (!icon) return "";
  return icon.toString("base64");
};
var getIcons = async (pids) => {
  const executables = await findExecutables(pids);
  const icons = await Promise.all(executables.map(({ bin }) => getIcon(bin)));
  return executables.reduce((acc, { pid }, index) => {
    acc[pid] = icons[index];
    return acc;
  }, {});
};
process.on("message", async (message) => {
  if (!process.send) return;
  if (message.type === "getAudioData") {
    const data = await getAudioData();
    process.send({ type: "audioData", payload: data });
  }
  if (message.type === "setVolume") {
    import_node_audio_volume_mixer.NodeAudioVolumeMixer.setAudioSessionVolumeLevelScalar(message.payload.pid, message.payload.volume);
  }
  if (message.type === "getIcons") {
    const icons = await getIcons(message.payload);
    process.send({ type: "icons", payload: icons });
  }
});
